request = {
    "method": "GET",
    "uri": uri("///keeping_slashes"),
    "version": (1, 1),
    "headers": [],
    "body": b""
}
